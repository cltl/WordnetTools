
#Usage
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity

#DUTCH
#Cornetto
#LEACOCK-CHODOROW
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --cdb-file "../resources/cdbsyn-latest.xml" --input "../input/sim-processing/word-pairs.txt" --method leacock-chodorow --pairs words --pos n
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --cdb-file "../resources/cdbsyn-latest.xml" --input "../input/sim-processing/synset-pairs.txt" --method leacock-chodorow --pairs synsets --pos n

#RESNIK
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --cdb-file "../resources/cdbsyn-latest.xml" --input "../input/sim-processing/word-pairs.txt" --method resnik --pairs words --subsumers "../resources/cornettosubsumers.cum" --pos n
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --cdb-file "../resources/cdbsyn-latest.xml" --input "../input/sim-processing/synset-pairs.txt" --method resnik --pairs synsets --subsumers "../resources/cornettosubsumers.cum" --pos n

#### WordnetLMF
#LEACOCK-CHODOROW
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --lmf-file "../resources/cornetto2.1.lmf.xml" --input "../input/word-pairs.txt" --method leacock-chodorow --pairs words --pos n
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --lmf-file "../resources/cornetto2,0.lmf.xml" --input "../input/synset-pairs.txt" --method leacock-chodorow --pairs synsets --pos n

#RESNIK
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --lmf-file "../resources/cornetto2.1.lmf.xml" --input "../input/sim-processing/word-pairs.txt" --method resnik --pairs words --subsumers "../resources/cornettosubsumers.cum" --pos n 
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --lmf-file "../resources/cornetto2.1.lmf.xml" --input "../input/sim-processing/synset-pairs.txt" --method resnik --pairs synsets --subsumers "../resources/cornettosubsumers.cum" --pos n


#ALL
java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --lmf-file "../resources/cornetto2.1.lmf.xml" --input "../input/sim-processing/word-pairs.txt" --method all --pairs words --subsumers "../resources/cornettosubsumers.cum" --pos n --relations "../resources/relations.txt" 

java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.Similarity --lmf-file "../resources/cornetto2.1.lmf.xml" --input "../input/sim-processing/synset-pairs.txt" --method all --pairs synsets --subsumers "../resources/cornettosubsumers.cum" --pos n --relations "../resources/relations.txt" 

