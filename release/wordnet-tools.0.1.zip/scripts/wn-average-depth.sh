#Cornetto
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.GetAverageDepth --cdb-file "../resources/cdbsyn-latest.xml"

#### WordnetLMF
java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.GetAverageDepth --lmf-file "../resources/cornetto2.1.lmf.xml" --pos n

#### WordnetLMF
java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.GetMaxDepth --lmf-file "../resources/cornetto2.1.lmf.xml" --pos n


#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.GetAverageDepth --lmf-file "../resources/wneng-30.lmf.xml"

### English GWG
#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.GetAverageDepth --gwg-file "../resources/wneng-30.gwg.xml"

