#### WordnetLMF
java -Xmx812m -cp /Tools/wordnet-tools.0.1/lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.TagKafFilesWithSynsets --wn-lmf "/Projects/THeSiS/ontologize/wordnet-tagging/cornetto-lmf-2.1.xml" --input-folder
"/Projects/THeSiS/june-12/Pandbrieven_Kerk_top500.kaf"
--extension
".kaf"