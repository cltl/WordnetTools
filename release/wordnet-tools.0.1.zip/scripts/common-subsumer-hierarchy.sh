#Create a subhierarchy of wordnet for a specific set of input words.
#--wn-lmf		<path to a wordnet file in wordn-lmf format> 
#--relations		<path to a text file with the relations y=that should be used to build the hierarchy> 
#--input-file		<path to the input file>
#--format	<format of the input file. Values are 'tuplemap', 'wordmap' and 'tagmap'>
#--pos	<part-of-speech considered for the input words>
#--proportion		<OPTIONAL: proportional frequency threshold, relative to the most frequent word, only works for 'tuplemap' format>
#--monosemous		<OPTIONAL: only consider input words that are monosemous>
#--first-hypernym		<OPTIONAL: take the first hypernym in case there are multiple hypernyms>

#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.BestCommonSubsumerHierarchy --wn-lmf "../resources/cornetto2.1.lmf.xml" --input-file "../input/kaf-processing/kaf.tuple-overview.functions" --relations "../resources/relations.txt" --format "tuplemap" --first-hypernym --pos v --proportion 0

#java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.BestCommonSubsumerHierarchy --wn-lmf "../resources/cornetto2.1.lmf.xml" --input-file "../input/kaf-processing/kaf.tuple-overview.objects" --relations "../resources/relations.txt" --format "tuplemap" --first-hypernym --pos n --proportion 0

java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.MostCommonSubsumerHierarchy --wn-lmf "../resources/cornetto2.1.lmf.xml" --input-file "../input/kaf-processing/kaf.tuple-overview.functions" --relations "../resources/relations.txt" --format "tuplemap" --first-hypernym --pos v --proportion 0

#### WordnetLMF
java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.main.MostCommonSubsumerHierarchy --wn-lmf "../resources/cornetto2.1.lmf.xml" --input-file "../input/kaf-processing/kaf.tuple-overview.objects" --relations "../resources/relations.txt" --format "tuplemap" --first-hypernym --pos n --proportion 0
