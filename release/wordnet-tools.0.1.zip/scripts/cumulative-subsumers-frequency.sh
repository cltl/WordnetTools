#### WordnetLMF
java -Xmx812m -cp ../lib/WordnetTools-1.0-jar-with-dependencies.jar vu.wntools.wnsimilarity.corpus.CumulateCorpusFrequency --lmf-file "../resources/cornetto2.1.lmf.xml" --corpus-freq "../resources/cornettolemmafreq.txt" --separator "/" --lemma-field 0 --pos-field 1 --freq-field 2

